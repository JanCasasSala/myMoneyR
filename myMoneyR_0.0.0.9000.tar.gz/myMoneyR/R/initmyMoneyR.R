initmyMoneyR<-function()
{
  rm(list=ls())

  if (!require(shiny)) install.packages('shiny')
  library(shiny)

  if (!require(shinydashboard)) install.packages('shinydashboard')
  library(shinydashboard)

  if (!require(dplyr)) install.packages('dplyr')
  library(dplyr)

  if (!require(DT)) install.packages('DT')
  library(DT)

  if (!require(lubridate)) install.packages('lubridate')
  library(lubridate)

  if (!require(readr)) install.packages('readr')
  library(readr)

  if (!require(tidyverse)) install.packages('tidyverse')
  library(tidyverse)

  if (!require(inspectdf)) install.packages('inspectdf')
  library(inspectdf)
  # library(installr)

  if (!require(BatchGetSymbols)) install.packages('BatchGetSymbols')
  library(BatchGetSymbols)

  if (!require(PerformanceAnalytics)) install.packages('PerformanceAnalytics')
  library(PerformanceAnalytics)

  if (!require(ggplot2)) install.packages('ggplot2')
  library(ggplot2)
  theme_set(theme_classic())

  if (!require(quantmod)) install.packages('quantmod')
  library(quantmod)

  if (!require(ggthemes)) install.packages('ggthemes')
  library(ggthemes)

  if (!require(systemfonts)) install.packages('systemfonts')
  library(systemfonts)

#  setwd("~/R/myMoneyR/data/")
#  getwd()

}

