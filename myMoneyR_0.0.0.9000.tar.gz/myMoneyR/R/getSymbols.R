getPreciosVenta<-function()
{
# set dates
first.date <- Sys.Date() - 60
last.date <- Sys.Date()
freq.data <- 'daily'
# set tickers
tickers <- c('MAP.MC','TEF.MC','BME.MC','SAN.MC', "ACS.MC")

l.out <- BatchGetSymbols(tickers = tickers,
                         first.date = first.date,
                         last.date = last.date,
                         freq.data = freq.data,
                         cache.folder = file.path(tempdir(),
                                                  'BGS_Cache') ) # cache in tempdir()

tickers1 <- l.out$df.tickers %>%
  mutate(empresa=str_sub(ticker,1,3)) %>%
  arrange(empresa,ref.date) %>%
  group_by(empresa) %>%
  summarise(precioVenta = last(price.close))

return(tickers1)
}

getGraficosCartera<-function()
{

first.date <- Sys.Date() - 120
last.date <- Sys.Date()
freq.data <- 'daily'
# set tickers
tickers <- c('MAP.MC','TEF.MC','IAG.MC','SAN.MC', "ACS.MC", "MAS.MC", "CABK.MC")

l.out <- BatchGetSymbols(tickers = tickers,
                         first.date = first.date,
                         last.date = last.date,
                         freq.data = freq.data,
                         cache.folder = file.path(tempdir(),
                                                  'BGS_Cache') ) # cache in tempdir()

p <- ggplot(l.out$df.tickers, aes(x = ref.date, y = price.close))
p <- p + geom_line()
p <- p + facet_wrap(~ticker, scales = 'free_y')
print(p)

return(l.out$df.tickers)
}

getCotizaciones<-function(tickers.vec)
{
  first.date <- Sys.Date() - 120
  last.date <- Sys.Date()
  freq.data <- 'daily'
# Example tickers.vec
# tickers <- c('MAP.MC','TEF.MC','IAG.MC','SAN.MC', "ACS.MC", "MAS.MC", "CABK.MC")

  l.out <- BatchGetSymbols(tickers = tickers.vec,
                           first.date = first.date,
                           last.date = last.date,
                           freq.data = freq.data,
                           cache.folder = file.path(tempdir(),
                                                    'BGS_Cache') ) # cache in tempdir()

return(l.out$df.tickers)
}





