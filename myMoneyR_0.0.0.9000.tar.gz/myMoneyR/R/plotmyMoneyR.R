plotColPurchaseValue<-function(wrk.df)
  {
  oup.gg <- ggplot2::ggplot(wrk.df, aes(ticker, purchaseValue))
  oup.gg <- oup.gg + geom_col(fill="tomato2") +
    labs(title="Purchase value portfolio",
         subtitle ="",
         caption="Fuente: myMoneyR",
         x = "Ticker",
         y="Purchase value") +
    theme(axis.text.x = element_text(angle=45, vjust=0.6)) +
    geom_text(aes(label=purchaseValue), vjust=0.2, size=3.0)

  return(oup.gg)
}

plotColStockValue<-function(wrk.df)
{
  oup.gg <- ggplot2::ggplot(wrk.df, aes(ticker, stockValue))
  oup.gg <- oup.gg + geom_col(fill="tomato2") +
    labs(title="Stock value portfolio",
         subtitle ="",
         caption="Fuente: myMoneyR",
         x = "Ticker",
         y="Stock value") +
    theme(axis.text.x = element_text(angle=45, vjust=0.6)) +
    geom_text(aes(label=stockValue), vjust=0.2, size=3.0)

  return(oup.gg)
}

plotColResultValue<-function(wrk.df)
{
  oup.gg <- ggplot2::ggplot(wrk.df, aes(ticker, result))
  oup.gg <- oup.gg + geom_col(fill="tomato2") +
    labs(title="Result value portfolio",
         subtitle ="",
         caption="Fuente: myMoneyR",
         x = "Ticker",
         y="Result value") +
    theme(axis.text.x = element_text(angle=45, vjust=0.6)) +
    geom_text(aes(label=result), vjust=0.2, size=3.0)

  return(oup.gg)
}

plotColValue<-function(wrk.df, type)
{
  sTitle <- switch(type,
                   "Purchase value portfolio",
                   "Stock value portfolio",
                   "Result value portfolio")
  sLabsy <- switch(type,
                   "Purchase value",
                   "Stock value",
                   "Result value")
  dFieldy <- switch(type,
                    wrk.df$purchaseValue,
                    wrk.df$stockValue,
                    wrk.df$result)

  oup.gg <- ggplot2::ggplot(wrk.df, aes(ticker,dFieldy))
  oup.gg <- oup.gg + geom_col(fill="tomato2") +
    labs(title=sTitle,
         subtitle ="",
         caption="Fuente: myMoneyR",
         x = "Ticker",
         y=sLabsy) +
    theme(axis.text.x = element_text(angle=45, vjust=0.6)) +
    geom_text(aes(label=result), vjust=0.2, size=3.0)

  return(oup.gg)
}

plotDonPurchaseValue<-function(wrk.df,type=1)
{
  dField <- switch(type,
                    wrk.df$purchaseValue,
                    wrk.df$stockValue,
                    wrk.df$result)

data <- data.frame(category=wrk.df$ticker,count=dField)

data$fraction <- data$count / sum(data$count)

# Compute the cumulative percentages (top of each rectangle)
data$ymax <- cumsum(data$fraction)

# Compute the bottom of each rectangle
data$ymin <- c(0, head(data$ymax, n=-1))

# Compute label position
data$labelPosition <- (data$ymax + data$ymin) / 2

# Compute a good label
data$label <- paste0(data$category, "\n value: ", data$count)

# Make the plot
oup.gg <-
  ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.8, aes(y=labelPosition, label=label), size=4.0) +
  scale_fill_brewer(palette=4) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  theme_void() +
  theme(legend.position = "none")

return(oup.gg)
}

plotPortfolioValue <- function(wrk.df, detailLevel=0){
# source getPorFolioValue(wrk.df, type)
  if (is.null(wrk.df)){
    return(NULLa)
  }

  #
  if (detailLevel==0){

    wrk.df <- wrk.df %>%
      unite(col="portfolio", portfolio, description, sep = " ")

    # wrk.df <- wrk.df %>%
    #   rename(xx = outcome)

    wrk.df <- wrk.df %>%
      select(portfolio,purchaseValue,stockValue,outcome)

    wrk.df <- gather(wrk.df,"dimensions","value",2:4)

    wrk.df <- wrk.df %>%
      arrange(portfolio,dimensions)

    # wrk.df <- wrk.df %>%
    #   mutate(dimensions = recode(dimensions, "xx" = "outcome"))

    sGgtitle <- "Holdings"

    oup.gg <-
      ggplot(wrk.df, aes(fill=dimensions, y=value, x=portfolio)) +
      geom_bar(position="dodge", stat="identity") +
      # geom_text(aes(label = n),
      #           vjust=-0.5) +
      labs(title=sGgtitle,
            subtitle = as.character(Sys.Date()),
            caption="Fuente: myMoneyR") +
      #          x = "Ticker",
      #          y="Dividendos") +
      #  scale_fill_viridis(discrete = T) +
#      ggtitle(sGgtitle) +
      #  coord_flip() +
      #  facet_wrap(~ticker) +
      #  theme_ipsum() +
      #  theme(legend.position="none") +
      #  xlab("") +
      theme_economist() +
      theme(
        axis.text = element_text(size = 10), #, color = "blue"),
        axis.text.x = element_text(angle = 90,
                                   hjust = 1,
                                   vjust = 0.5))+
      scale_fill_manual(values = c("red",
                                   "blue",
                                   "cyan"))
      theme_economist()

      #geom_text(aes(label=dimensions), vjust=0.2, size=3.0)
      # scale_color_manual (value = c ("# 69b3a2", "púrpura", "negro"))
  }


  # Todos los tickers de un portafolios         -> desglose por tickers
  if (detailLevel==1){

    # Search description portfolio
    tmp.df <- wrk.df %>%
      distinct(portfolio)
    portfolioId = tmp.df$portfolio
    oup.df<- getFile("portfolio.csv") %>%
      filter(portfolio==portfolioId)
    sGgtitle <- oup.df$description

    # wrk.df <- wrk.df %>%
    #   rename(xx = outcome)

    wrk.df <- wrk.df %>%
      select(ticker,purchaseValue,stockValue,outcome)

    wrk.df <- gather(wrk.df,"dimensions","value",3:5)

    wrk.df <- wrk.df %>%
      arrange(ticker,dimensions)

    oup.gg <-
      ggplot(wrk.df, aes(fill=dimensions, y=value, x=ticker)) +
      geom_bar(position="dodge", stat="identity") +
      labs(title=sGgtitle,
           subtitle = as.character(Sys.Date()),
           caption="Fuente: myMoneyR") +
      #  coord_flip() +
      #  facet_wrap(~ticker) +
      #  theme_ipsum() +
      #  theme(legend.position="none") +
      #  xlab("") +
      theme_economist() +
      theme(
        axis.text = element_text(size = 10), #, color = "blue"),
        axis.text.x = element_text(angle = 90,
                                   hjust = 1,
                                   vjust = 0.5))+
      scale_fill_manual(values = c("red",
                                   "blue",
                                   "cyan"))

  }

  # Todas las transacciones de un portafolios         -> desglose por transacciones
  if (detailLevel==2){

    wrk.df <- ungroup(wrk.df)
    # Search description portfolio
    tmp.df <- wrk.df %>%
      distinct(portfolio)

    # portfolioId = tmp.df$portfolio
    # oup.df<- getFile("portfolio.csv") %>%
    #   filter(portfolio==portfolioId)
    # sGgtitle <- oup.df$description

     wrk.df <- wrk.df %>%
       unite(col="ticker", ticker, valueDate, ope, sep = " ")

    # wrk.df <- wrk.df %>%
    #   rename(xx = outcome)

    wrk.df <- wrk.df %>%
      select(ticker,purchaseValue,stockValue,outcome)

    wrk.df <- gather(wrk.df,"dimensions","value",2:4)

    oup.gg <-
      ggplot(wrk.df, aes(fill=dimensions, y=value, x=ticker)) +
      geom_bar(position="dodge", stat="identity") +
      labs(title="",
           subtitle = as.character(Sys.Date()),
           caption="Fuente: myMoneyR") +
      coord_flip() +
      theme(
        axis.text = element_text(size = 10), #, color = "blue"))
        # scale_fill_manual(values = c("red",
        #                              "blue",
        #                              "cyan"))

        )
  }


  return(oup.gg)
}

# # Graficos por dimensiones
# plotDivCartera<-function(cartera.df)
# {
#   g <- ggplot2::ggplot(cartera.df, aes(empresa, dividendos))
#   g <- g + geom_col(fill="tomato2") +
#     labs(title="Valoración de la cartera",
#          subtitle ="Dividendos",
#          caption="Fuente: myMoneyR",
#          x = "Ticker",
#          y="Dividendos") +
#     theme(axis.text.x = element_text(angle=45, vjust=0.6)) +
#     geom_text(aes(label=dividendos), vjust=0.2, size=3.0)
#
#   return(g)
#}
