getFile<-function(fileName){

  oup.df <- NULL

  if (!is.null(fileName)){

    if (class(fileName)=="character" & nchar(fileName)>0) {

      fileName <- paste("data",fileName,sep="/")

      if (file.exists(fileName)){
        oup.df <- read_csv(fileName)
      }

    rm(fileName)
    }
  }
  return(oup.df)
}

getPortfolio<-function(sDescription){

  wrk.df <- NULL
  wrk.df <- getPortfolios()
  if (is.null(wrk.df)){return(wrk.df)}

  wrk.df <- wrk.df %>%
             filter(description==sDescription)

   if (nrow(wrk.df)==1) { portfolio <- wrk.df$portfolio[1]
   } else { return (NULL) }

  return(portfolio)
}

getPortfolios<-function(){

  wrk.df <- NULL
  wrk.df <- getFile("portfolio.csv")
  if (is.null(wrk.df)){return(wrk.df)}

  wrk.df <- wrk.df %>%
    arrange(portfolio)

  wrk.df <- data.frame(wrk.df)

  return(wrk.df)
}

getHoldings<-function(transactionType=1, portfolioId=0){

  fileName <- switch(transactionType,"purchases.csv","sales.csv")

  wrk.df <- NULL
  wrk.df <- getFile(fileName)
  if (is.null(wrk.df)){return(wrk.df)}

  if (nrow(wrk.df)>0){

    if (portfolioId==0){
      wrk.df <- wrk.df %>%
        distinct(portfolio,ticker) %>%
        arrange(portfolio,ticker)

    } else {

      wrk.df <- wrk.df %>%
        distinct(portfolio,ticker) %>%
        arrange(portfolio,ticker) %>%
        filter(portfolio == portfolioId)

    }
  }

  return(wrk.df)
}

getTransactions<-function(transactionType=1, portfolioId=NULL, tickerId=NULL){

  fileName <- switch(transactionType,"purchases.csv","sales.csv")

  wrk.df <- NULL
  wrk.df <- getFile(fileName)
  if (is.null(wrk.df)){return(wrk.df)}

  if (nrow(wrk.df)>0){

    if (!is.null(portfolioId)){ wrk.df <- wrk.df %>%
       filter(portfolio==portfolioId) }

    if (!is.null(tickerId)){ wrk.df <- wrk.df %>%
      filter(ticker==tickerId) }

    wrk.df <- wrk.df %>%
      arrange(valueDate)
  }

  rm(fileName)

  return(wrk.df)
}

getTransactionsBalance<-function(portfolioId=NULL, tickerId=NULL){

  out.df = NULL

  purchases.df <- getTransactions(transactionType=1, portfolioId, tickerId)
  if (is.null(purchases.df)){ return(out.df) }

  if (nrow(purchases.df)>0){
    purchases.df <- purchases.df %>%
      arrange(portfolio,valueDate,ticker) %>%
      mutate(transaction = 1:n(), operation=1)

  } else { return(out.df) }

  sales.df <- getTransactions(transactionType=2, portfolioId, tickerId)
  if (is.null(sales.df)){ return(purchases.df) }

  if (nrow(sales.df)>0){
    sales.df <- sales.df %>%
      arrange(portfolio,valueDate,ticker) %>%
      mutate(transaction = 1:n(), operation=-1)

  } else { return(purchases.df) }


  for (i in 1:nrow(sales.df)) {

    for (j in 1:nrow(purchases.df)) {

      if (purchases.df$portfolio[j] == sales.df$portfolio[i]) {

        if (purchases.df$ticker[j] == sales.df$ticker[i]) {

          if (purchases.df$stocks[j]>= sales.df$stocks[i]) {

            purchases.df$stocks[j] <- purchases.df$stocks[j]-sales.df$stocks[i]
            sales.df$stocks[i] <- 0
            break

          } else {

            sales.df$stocks[i] <- sales.df$stocks[i]-purchases.df$stocks[j]
            purchases.df$stocks[j] <- 0

          }

        }

      }

    }

  }


  out.df <- purchases.df %>%
    filter(stocks>0)

  return(out.df)
}

getTransactionsOutcome<-function(portfolioId=NULL, tickerId=NULL){

  out.df = NULL

  purchases.df <- getTransactions(transactionType=1, portfolioId, tickerId)
  if (is.null(purchases.df)){ return(out.df) }

  if (nrow(purchases.df)>0){

    purchases.df <- purchases.df %>%
      arrange(portfolio,valueDate,ticker) %>%
      mutate(transaction = 1:n(), operation=1)
  }


  sales.df <- getTransactions(transactionType=2, portfolioId, tickerId)
  if (is.null(sales.df)){ return(out.df) }

  if (nrow(sales.df)>0){

    sales.df <- sales.df %>%
      arrange(portfolio,valueDate,ticker) %>%
      mutate(transaction = 1:n(),
             operation=-1,
             stocksInitial=stocks,
             purchaseValue=0,
             purchaseDate = Sys.Date(),
             onePurchase=1 )
  }


  if (nrow(purchases.df)==0 | nrow(sales.df)==0) { return(out.df) }


  for (i in 1:nrow(sales.df)) {

    for (j in 1:nrow(purchases.df)) {

      if (purchases.df$portfolio[j] == sales.df$portfolio[i]) {

        if (purchases.df$ticker[j] == sales.df$ticker[i]) {

          if (purchases.df$stocks[j]>= sales.df$stocks[i]) {
            # Movimiento de la compra >= movimiento de la venta
            # Valor de compra de esta venta = acciones de esta venta * precio compra de esta compra
            sales.df$purchaseValue[i] <- sales.df$purchaseValue[i] + (sales.df$stocks[i] * purchases.df$price[j])
            # Acciones del mov de compra = acciones del mov de compra - acciones de venta vendidas
            purchases.df$stocks[j] <- purchases.df$stocks[j]-sales.df$stocks[i]
            sales.df$stocks[i] <- 0
            sales.df$purchaseDate[i] <- purchases.df$valueDate[j]
            sales.df$onePurchase[i] <- 1

            break

          } else {
            # Mov de compra < mov de venta
            # Valor de compra de esta venta = acciones de esta compra * precio de compra de esta compra
            sales.df$purchaseValue[i] <- sales.df$purchaseValue[i] + (purchases.df$stocks[j] * purchases.df$price[j])
            # Acciones del mov de venta = acciones del mov de venta - acciones de compra
            sales.df$stocks[i] <- sales.df$stocks[i]-purchases.df$stocks[j]
            purchases.df$stocks[j] <- 0
            sales.df$purchaseDate[i] <- purchases.df$valueDate[j]
            sales.df$onePurchase[i] <- 0

          }

        }

      }

    }

  }


  out.df <- sales.df %>%
    mutate(purchasePrice = round(purchaseValue/stocksInitial,2),
           saleValue = round(stocksInitial*price,2),
           saleDate = valueDate,
           outcome= (saleValue-purchaseValue))

  return(out.df)
}

getHoldingsVec<-function(transactionType=1, portfolioId=NULL){

  wrk.df <- NULL
  wrk.df <- getHoldings(transactionType, portfolioId)
  if (is.null(wrk.df)){return(wrk.df)}

  if (nrow(wrk.df)>0){
    wrk.vec <- wrk.df %>%
      pull(ticker)
  }

  return(wrk.vec)
}

getCmbPortfolio<-function(){

  wrk.df <- NULL
  wrk.df <- getPortfolios()
  if (is.null(wrk.df)){return(wrk.df)}


#  wrk.df <-tibble::add_row(wrk.df,portfolio=0,description="ALL", .before = 1)
   wrk.df <- wrk.df %>%
                arrange(portfolio) %>%
                select(description)

  return(wrk.df)
}

getCotizacionesPortfolio_Ticker<-function(portfolioId){

  out.df <- NULL
  out.df <- getTransactionsBalance(portfolioId)
  if (is.null(out.df)){ return (out.df) }

  if (nrow(out.df)>0){

    tickers.vec <- out.df %>%
      distinct(ticker) %>%
      pull(ticker)

    tickers.df <- getCotizaciones(tickers.vec) %>%
      select(ticker,price.close,ref.date)

    out.df <- left_join(tickers.df,out.df,by="ticker")

    out.df <- out.df %>%
      filter(ref.date>=valueDate)

    rm(portfolioId)
    rm(tickers.vec)
    rm(tickers.df)
  }


  return(out.df)
}

getPortfolioOutcome <-function(portfolioId, detailLevel=0){

  # DataInput
  oup.df <-  getTransactionsOutcome(portfolioId)             # sales.csv

  if (is.null(oup.df)){
    return(oup.df)
  }
  if (nrow(oup.df)==0){
    return(oup.df)
  }

  # Granularidad

  # Cartera                                     -> resumen de una cartera
  # LA CORRECTE ES getHoldingsOutcome(type=1,detailLevel)
  # Aquí només fa 1 portfolio
  if (detailLevel==0){
    oup.df <- oup.df %>%
      summarise(portfolio=portfolioId,
                purchaseValue=sum(purchaseValue),
                saleValue=sum(saleValue),
                outcome=sum(outcome),
                percent=round((outcome*100)/purchaseValue,2),
                tickers=n_distinct(ticker))

    portfolios.df <- getPortfolios()
    oup.df <- left_join(oup.df,portfolios.df,by="portfolio")

  }

  # Todos los tickers de un portafolios         -> desglose por tickers
  if (detailLevel==1){
    oup.df <- oup.df %>%
      group_by(portfolio,ticker) %>%
      summarise(stocks=sum(stocksInitial),
                purchaseValue=sum(purchaseValue),
                saleValue=sum(saleValue),
                outcome=sum(outcome),
                percent=round((outcome*100)/purchaseValue,2))
  }

  # Todas las operaciones de un ticker          -> desglose por operaciones
  if (detailLevel==2){
    # oup.df <- oup.df %>%
    #   arrange(valueDate,ticker) %>%
    #   mutate(ope = 1:n()) %>%
    #   group_by(valueDate,ticker,ope)

    oup.df <- oup.df %>%
      select(portfolio,ticker,transaction,stocksInitial,
             purchaseDate,purchasePrice,purchaseValue,
             saleDate,price,saleValue,
             outcome,onePurchase)
  }


  return(oup.df)
}

getPortfolioValue <-function(portfolioId, detailLevel=0){


  # DataInput
  oup.df <- getCotizacionesPortfolio_Ticker(portfolioId)    # 1 purchases.csv

  if (is.null(oup.df)){
    return(oup.df)
  }
  if (nrow(oup.df)==0){
    return(oup.df)
  }

  oup.df <- oup.df %>%
    filter(ref.date==max(ref.date)) %>%
    mutate(purchaseValue=round(stocks*price,2),
           stockValue=round(stocks*price.close,2),
           outcome=(stockValue-purchaseValue))

  # Granularidad

  # Cartera                                     -> resumen de una cartera
  # LA CORRECTE ES getHoldingsValue(type=1,detailLevel)
  # Aquí només fa 1 portfolio
  if (detailLevel==0){
    oup.df <- oup.df %>%
                summarise(portfolio=portfolioId,
                  purchaseValue=sum(purchaseValue),
                  stockValue=sum(stockValue),
                  outcome=(stockValue-purchaseValue),
                  percent=round((outcome*100)/purchaseValue,2),
                  tickers=n_distinct(ticker))

    portfolios.df <- getPortfolios()
    oup.df <- left_join(oup.df,portfolios.df,by="portfolio")

    }

  # Todos los tickers de un portafolios         -> desglose por tickers
  if (detailLevel==1){
    oup.df <- oup.df %>%
                group_by(portfolio,ticker) %>%
                summarise(stocks=sum(stocks),
                          purchaseValue=sum(purchaseValue),
                          stockValue=sum(stockValue),
                          outcome=(stockValue-purchaseValue),
                          percent=round((outcome*100)/purchaseValue,2))
    }

  # Todas las operaciones de un ticker          -> desglose por operaciones
  if (detailLevel==2){
    oup.df <- oup.df %>%
                arrange(valueDate,ticker) %>%
                mutate(ope = 1:n()) %>%
                group_by(valueDate,ticker,ope)

    oup.df <- oup.df %>%
                select(ref.date,portfolio,valueDate,ticker,
                       ope,stocks,price,purchaseValue,
                       price.close,stockValue,outcome)
  }


  return(oup.df)
}

getHoldingsValue<-function(transactionType=1, detailLevel=0){

  out.df = NULL

  wrk.df <- NULL
  wrk.df <- getPortfolios()
  if (is.null(wrk.df)){ return(wrk.df) }

  portfolio.vec  <- wrk.df %>%
    pull(portfolio)

  portfolio.vec  <- portfolio.vec[portfolio.vec>0]

  fTime <- TRUE
  for (f in seq_along(portfolio.vec)) {

    res.df <- switch(transactionType,                                        #   transactionType
                     getPortfolioValue(portfolio.vec[f], detailLevel),       # 1.purchases.csv
                     getPortfolioOutcome(portfolio.vec[f], detailLevel))     # 2.sales.csv


    if (!is.null(res.df)){

      if (nrow(res.df) > 0) {

        if (fTime == TRUE) {
          out.df <- res.df
          fTime <- FALSE
        } else {
          # The loop is slowed by this call to cbind that grows the object
          out.df <- bind_rows(out.df, res.df)
        }

      }
    }

  }

  return(out.df)
}
